import random

print("                    SIMPLE HANGMAN GAME                  ")
print(     )
def get_word():
#There are few words in the list we could find if any word is wrong they show inorrrect & reduces yours attempts.  
    word_list = ["'python', 'java', 'javascript', 'ruby', 'php'"]
    return random.choice(word_list)

def hangman():
    word = get_word()
    guessed_letters = []
    incorrect_guesses = 0
    max_attempts = 5
    word_display = ['_'] * len(word)

    while '_' in word_display and incorrect_guesses < max_attempts:
        guess = input("Guess a letter : ")
        if guess in guessed_letters:
            print("You already guessed that letter!")
        elif guess in word:
            print("Correct guess!")
            guessed_letters.append(guess)
            for i in range(len(word)):
                if word[i] == guess:
                    word_display[i] = guess
            print("Word: ", ' '.join(word_display))
        else:
            print("Incorrect guess! TRY AGAIN")
            guessed_letters.append(guess)
            incorrect_guesses += 1
            print("Attempts left:", max_attempts - incorrect_guesses)
    
    if '_' not in word_display:
        print("You guessed the word!")
    else:
        print("Out of attempts. The word was:", word)

hangman()
print("                    THANK YOU FOR PLAYING   ")
print(   )
print("                      HOPE YOU ENJOYED IT               " 
      
"                      @ copyrights reserved by Abhishek pathak")